# Signály za týden 2026-09-28 až 2026-10-04

Návštěvy: 200, zobrazení stránek: 500.

## Rychlost stránek u skutečných uživatelů (CrUX)

Percentil p75 za klouzavých 28 dní (2026-09-20 až 2026-10-17); mezitýdenní srovnání z toho nejde. Hodnocení podle prahů Googlu (LCP 2,5 a 4 s, INP 200 a 500 ms, CLS 0,1 a 0,25). „bez dat“: adresa nemá v Chrome dost návštěv.

| Typ stránky | Zařízení | LCP | INP | CLS |
|---|---|---|---|---|
| celý web | telefon | 2100 ms (dobrá) | 180 ms (dobrá) | 0.05 (dobrá) |
| celý web | počítač | bez dat |  |  |
| titulka | telefon | bez dat |  |  |
| titulka | počítač | bez dat |  |  |
| škola | telefon | bez dat |  |  |
| škola | počítač | bez dat |  |  |
| obor | telefon | bez dat |  |  |
| obor | počítač | bez dat |  |  |
| město | telefon | bez dat |  |  |
| město | počítač | bez dat |  |  |
| simulátor | telefon | 4500 ms (špatná) | 350 ms (ke zlepšení) | 0.12 (ke zlepšení) |
| simulátor | počítač | bez dat |  |  |

Adresy: titulka `/`, škola `/skola/600005691-gymnazium-jana-keplera-parlerova`, obor `/skola/600005691-gymnazium-jana-keplera-parlerova-gymnazium-4lete`, město `/mesto/praha`, simulátor `/simulator`.

## Nejnavštěvovanější stránky

| Stránka | Zobrazení |
|---|---|
| /mesto/brno | 120 |
| /simulator | 60 |
| /skola/x | 12 |

## Nejrychleji rostoucí stránky (proti minulému týdnu)

| Stránka | Zobrazení | Minulý týden |
|---|---|---|
| /simulator | 60 | 10 |
| /mesto/brno | 120 | 100 |
| /skola/x | 12 | 0 |

## Stránky s vysokým podílem odchodů (aspoň 20 návštěv, odchody od 70 %)

| Stránka | Návštěvy | Podíl odchodů |
|---|---|---|
| /simulator | 50 | 80 % |

## Události (kategorie)

| Kategorie | Události |
|---|---|
| simulator | 33 |

## Události (akce)

| Akce | Události |
|---|---|
| simulator | 33 |

## Hlášení a opravy od škol podle oblasti (otevřená issues)

| Oblast | Počet |
|---|---|
| oblast:data | 2 |
